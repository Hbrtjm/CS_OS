
#include <stdio.h>

int main(int argc, char* argv[])
{
	for(int i = 10;i >= 0;i--)
	{
		printf("%d\n",i);
	}
	return 0;
}

