#ifndef SYSTEMV_H
#define SYSTEMV_H

#pragma once

#define PROJ_ID 0
#define SEM_NAME "/sem_printers"
#define MSG_SIZE 11
#define MAX_MSG 10
#define SHARED_NAME "/shm_printers"

typedef int sem;

typedef int shm;

// Structure for messages

#endif

