
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <string.h>
#include <errno.h>

#define PATH "/tmp"
#define BUFFER_SIZE 1024
#define ID 0

int main(int argc, char const *argv[])
{
char * shmAddr;

// convert path and identifier to System V IPC key
key_t key= ... (PATH,ID);

// Create shared memory segment
// the return value is the shared memory block identifier - i.e. shmid
int shmid;
if ((shmid= ... ==-1)
{
fprintf(stderr, "... :%s\n", strerror(errno));
exit(1);
}

// Map shared memory segments to process address space
shmAddr = ... (shmid, ... );
if(shmAddr==...)
{
fprintf(stderr, ":%s\n", strerror(errno));
}

printf("%s\n",shmAddr);

// Disconnect
...
// Remove shared memory segment
...

return 0;
}

/*
gcc -o shm_read shm_read.c
*/