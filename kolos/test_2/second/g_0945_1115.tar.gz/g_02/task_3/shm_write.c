// Create a unique key to identify the current System V inter-process communication (IPC)
key_t key= ...(PATH,ID);

// Create a shared memory segment
// the returned value is the shared memory block identifier - i.e. shmid
int shmid;
if ((shmid= ... ==-1)
{
fprintf(stderr, "... :%s\n", strerror(errno));
exit(1);
}

//Map shared memory segments to process address space
shmAddr= ... (shmid, ...);
if(shmAddr== ... )
{
fprintf(stderr, ":%s\n", strerror(errno));
}

// Copy dataAddr to shmAddr
... (shmAddr,dataAddr);

// detach process memory from shared memory
if ( ... ==-1)
{
fprintf(stderr, "... :%s\n", strerror(errno));
}
return 0;
}

/*
gcc -o shm_write shm_write.c
*/
