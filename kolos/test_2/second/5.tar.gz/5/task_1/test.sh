#!/bin/bash

./main 3 4 5